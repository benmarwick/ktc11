## Test `analogue` using the `testthat` package

## Setup
library("testthat")

## Runs the tests in tests/testthat
test_check("analogue")
