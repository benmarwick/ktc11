`fuse.matrix` <- function(..., weights = NULL) {
    return(fuse.dist(..., weights = weights))
}
