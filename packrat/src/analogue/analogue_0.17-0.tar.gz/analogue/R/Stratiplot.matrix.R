`Stratiplot.matrix` <- function(x, ...) {
    x <- as.data.frame(x)
    Stratiplot.default(x, ...)
}
