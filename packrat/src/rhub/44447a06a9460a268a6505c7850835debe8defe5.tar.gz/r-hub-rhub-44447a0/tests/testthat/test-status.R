
context("status")

test_that("my_curl_stream", {

  reader <- function(output) {
    out <- readBin(output, "raw", file.info(output)$size)
    pos <- 1
    function(con, what, n = 1L) {
      
    }

    
    
  }
  ## TODO
})
