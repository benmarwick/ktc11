library(testthat)
library(rstudioapi)

test_check("rstudioapi")
