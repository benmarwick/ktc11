library(testthat)
library(clisymbols)

test_check("clisymbols")
